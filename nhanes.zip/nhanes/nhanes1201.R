rm(list=ls())
library("writexl")
library("survey")
library("haven")
setwd("/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/nhanes")
source("/Volumes/wangl29/Calibration_svy/subfunctions.R")

read.data = function(year){
  file.names = list.files(path = year)
  nrows=NULL
  nhanes.yr = NULL
  for (i in 1:length(file.names)){
    tmp = read_xpt(paste0(year, "/", file.names[i]))
    if(is.null(nhanes.yr)){
      nhanes.yr = tmp
    } else{
      nhanes.yr = merge(tmp, nhanes.yr, by="SEQN", all=T)
    }
    nrows = c(nrows, nrow(tmp))
  }
  nhanes.yr
  
  return(list(nhanes.yr = nhanes.yr, nrows = nrows))
}
nhanes11 = read.data(year = "11")$nhanes.yr; #read.data("11")$nrows
nhanes13 = read.data(year = "13")$nhanes.yr; #read.data("13")$nrows
nhanes15 = read.data(year = "15")$nhanes.yr; #read.data("15")$nrows
nhanes17 = read.data(year = "17")$nhanes.yr; #read.data("17")$nrows

# Variable names
dsgn.vars = c("SDMVPSU", "SDMVSTRA", "WTINT2YR", "WTMEC2YR")
# Demograph      age in yrs, gender,     race4,      educ(<20), educ(>20)    martl
Demgph.vars = c("RIDAGEYR", "RIAGENDR", "RIDRETH1", "DMDEDUC3", "DMDEDUC2", "DMDMARTL") 
# Income     fam inc/yr, inc/pov,    fam inc/mth, pov indx,   pov cat
inc.vars = c("INDFMIN2", "INDFMPIR", "IND235",    "INDFMMPC", "INDFMMPI")
#Alcohol      12 drks/1 yr? 12 drks lf?  ever drks? freq lst yr,                      #drks/dy    #dys>4/5 drks                   >4/5 drks/dy?   
Alch.vars = c("ALQ101",     "ALQ110",   "ALQ111",   "ALQ120Q",  "ALQ120U", "ALQ121",  "ALQ130",   "ALQ141Q", "ALQ141U", "ALQ142", "ALQ151")
# Highe blood pressure
bp.vars = c("BPQ020",  "BPXSY1",  "BPXDI1",  "BPXSY2",  "BPXDI2",  "BPXSY3",  "BPXDI3", "BPXSY4", "BPXDI4",
            "BPXOSY1", "BPXODI1", "BPXOSY2", "BPXODI2", "BPXOSY3", "BPXODI3")
# Diabetes    diab?     prediab?  riks?     fam hist,  overwght,  ges. diab, baby>9lbs, fst glcs, %gly,    fam hist  
Diab.vars = c("DIQ010", "DIQ160", "DIQ170", "DIQ175A", "DIQ175B", "DIQ175S", "DIQ175F", "LBXGLU", "LBXGH", "DIQ175A")
# Health insurance
ins.vars = "HIQ011"
# Smoking  100 cig?  age strt  curnt?    quit time             #cig qt   #dys smk/mth #cig/dy   #cig lf   ag strt   
smk.vars=c("SMQ020", "SMD030", "SMQ040", "SMQ050Q", "SMQ050U", "SMD057", "SMD641",    "SMD650", "SMQ621", "SMD630")
# Fat       A/G ratio, Andriod %,  Gynoid %,   abdominal, Subcutaneous,visceral,   
fat.vars=c("DXXAGRAT", "DXXAPFAT", "DXXGPFAT", "DXXTATA", "DXXSATA",   "DXXVFATA", 
          #total %,   trunk %，  trunk(g),   total(g),   triglycerides, gamma-glutamyl transferase, ALT
           "DXDTOPF", "DXDTRPF", "DXXTRFAT", "DXDTOFAT", "LBXSTR",      "LBXSGTSI",                 "LBXSATSI")
# Body measures BMI,  waist,     hght(cm) wght(kg), slf ht(ichs), slf wt(pds)
bdy.vars=c("BMXBMI", "BMXWAIST", "BMXHT", "BMXWT",  "WHD010",     "WHD020")
# Physical activities
#Variable	Label	                                  Score
#PAD615	  Vigorous work-related activity	        8.0
#PAD630	  Moderate work-related activity	        4.0
#PAD645	  Walking or bicycling for transportation	4.0
#PAD660	  Vigorous leisure-time physical activity	8.0
#PAD675	  Moderate leisure-time physical activity	4.0
#           vig wk,   #dys vig wk, #mins vig wk, md wk,    #dys md wk  #mins md wk, wk/bk,    #dys wk/bk, #min wk/bk   
pa.vars = c("PAQ605", "PAQ610",    "PAD615",     "PAQ620", "PAQ625",   "PAD630",    "PAQ635", "PAQ640",   "PAD645",    
            #           vig rc,   #dys vig rc, #mins vig rc, md rc,    #dys md rc  #mins md rc,
            "PAQ650", "PAQ655",    "PAD660",     "PAQ665", "PAQ670",   "PAD675")

# CAP
cap.vars=c("LUXCAPM", "LUXCPIQR")

cmn.vars=c(dsgn.vars, Demgph.vars, inc.vars, bdy.vars, fat.vars, bp.vars, smk.vars, Alch.vars, pa.vars, ins.vars, Diab.vars)
cmn.vars[!(cmn.vars%in%names(nhanes11))]
cmn.vars[!(cmn.vars%in%names(nhanes13))]
cmn.vars[!(cmn.vars%in%names(nhanes15))]
cmn.vars[!(cmn.vars%in%names(nhanes17))]
nhanes11 = nhanes11[(nhanes11$RIDAGEYR>=18),cmn.vars[(cmn.vars%in%names(nhanes11))]]; nhanes11$cycle=1
nhanes13 = nhanes13[(nhanes13$RIDAGEYR>=18),cmn.vars[(cmn.vars%in%names(nhanes13))]]; nhanes13$cycle=2
nhanes15 = nhanes15[(nhanes15$RIDAGEYR>=18),cmn.vars[(cmn.vars%in%names(nhanes15))]]; nhanes15$cycle=3
nhanes = rbind(nhanes11, nhanes13, nhanes15)
nhanes$LUXCAPM=NA
nhanes$LUXCPIQR=NA
nhanes$alchl = 2-nhanes$ALQ101
nhanes$alchl[nhanes$ALQ110==1] = 1
nhanes$alchl[nhanes$ALQ110==9] = 0
table(nhanes$alchl[(nhanes$cycle==1)])
dys = nhanes$ALQ120U
dys[(nhanes$ALQ101==2)&(nhanes$ALQ110==2)]=0
dys[nhanes$ALQ120Q==0]=1
dys[nhanes$ALQ120U==1]=7
dys[nhanes$ALQ120U==2]=365.25/12
dys[nhanes$ALQ120U==3]=365.25
nhanes$ach_freq=nhanes$ALQ120Q/dys
nhanes$ach_freq[nhanes$alchl==0]=0
table(nhanes$ach_freq[nhanes$cycle==1], useNA = "ifany")
nhanes$ALQ130[nhanes$ALQ130>82]=NA
nhanes$ALQ130[nhanes$ALQ130>15]=15
nhanes$ALQ130[(nhanes$ALQ101==2)&(nhanes$ALQ110==2)]=0
table(nhanes$ALQ130,useNA = "ifany")
nhanes$drk_pdy = nhanes$ach_freq*nhanes$ALQ130
nhanes$alc3 = 1
nhanes$alc3[((nhanes$ALQ101==1)|(nhanes$ALQ110==1))&(nhanes$ALQ120Q<=365)&(nhanes$ALQ120Q>0)]=3
nhanes$alc3[((nhanes$ALQ101==1)|(nhanes$ALQ110==1))&(nhanes$ALQ120Q==0)]=2
table(nhanes$alc3, useNA = "ifany")
table(nhanes$alc3, nhanes$drk_pdy==0, useNA = "ifany")
nhanes$drk_pdy[nhanes$alc3==2]=0
nhanes$drk_pdy[(nhanes$alc3==3)&(is.na(nhanes$drk_pdy))]=mean(nhanes$drk_pdy[(nhanes$alc3==3)&(!is.na(nhanes$drk_pdy))])
nhanes$alc2=nhanes$alc3
nhanes$alc2[((nhanes$drk_pdy*365.25)<12)|(nhanes$alc3==2)]=1
nhanes$alc2[nhanes$alc2==3]=2
nhanes$alc2=nhanes$alc2-1
table(nhanes$alc2, useNA = "ifany")
table(nhanes$alc2, nhanes$alc3, useNA = "ifany")

nhanes17 = cbind(nhanes17[(nhanes17$RIDAGEYR>=18),
                          cmn.vars[(cmn.vars%in%names(nhanes17))]],
                 cycle=4,
                 nhanes17[(nhanes17$RIDAGEYR>=18),cap.vars])
nhanes17$ach_freq=NA
nhanes17$ach_freq[nhanes17$ALQ121==1]=1
nhanes17$ach_freq[nhanes17$ALQ121==2]=0.75
nhanes17$ach_freq[nhanes17$ALQ121==3]=3.5/7
nhanes17$ach_freq[nhanes17$ALQ121==4]=2/7
nhanes17$ach_freq[nhanes17$ALQ121==5]=1/7
nhanes17$ach_freq[nhanes17$ALQ121==6]=2.5/(365.25/12)
nhanes17$ach_freq[nhanes17$ALQ121==7]=1/(365.25/12)
nhanes17$ach_freq[nhanes17$ALQ121==8]=9/365.25
nhanes17$ach_freq[nhanes17$ALQ121==9]=4.5/365.25
nhanes17$ach_freq[nhanes17$ALQ121==10]=1.5/365.25
nhanes17$ach_freq[(nhanes17$ALQ121==0)|(nhanes17$ALQ111==2)]=0
table(nhanes17$ach_freq, useNA = "ifany")
nhanes17$ALQ130[nhanes17$ALQ130>15]=NA
nhanes17$ALQ130[(nhanes17$ALQ121==0)|(nhanes17$ALQ111==2)]=0
nhanes17$drk_pdy = nhanes17$ach_freq*nhanes17$ALQ130
table(nhanes17$drk_pdy, useNA = "ifany")
nhanes17$alc2 = 0
nhanes17$alc2[(nhanes17$drk_pdy*365.25)>12]=1
table(nhanes17$alc2,useNA = "ifany")
table(nhanes17$alc2, nhanes17$drk_pdy, useNA = "ifany")

# Blood pressure
#nhanes 11-15, mercury device
bp.sy = nhanes[,bp.vars[c(2,4,6,8)]]
bp.di = nhanes[,bp.vars[c(3,5,7,9)]]
bp.sy[is.na(bp.sy)]=0
bp.di[is.na(bp.di)]=0
nhanes$bp.sy.m = apply(bp.sy,1,sum)/apply(bp.sy!=0,1,sum)
nhanes$bp.di.m = apply(bp.di,1,sum)/apply(bp.di!=0,1,sum)
nhanes$bpo.sy.m = NA
nhanes$bpo.di.m = NA
# nhanes17-18, mercury device
bp.sy = nhanes17[,bp.vars[c(2,4,6,8)]]
bp.di = nhanes17[,bp.vars[c(3,5,7,9)]]
bp.sy[is.na(bp.sy)]=0
bp.di[is.na(bp.di)]=0
nhanes17$bp.sy.m = apply(bp.sy,1,sum)/apply(bp.sy!=0,1,sum)
nhanes17$bp.di.m = apply(bp.di,1,sum)/apply(bp.di!=0,1,sum)
var_non0 = function(x) var(x[!x==0])
bp.sy.v = apply(bp.sy,1,var_non0)
bp.di.v = apply(bp.di,1,var_non0)
# nhanes17-18, oscillometric device
bpo.sy = nhanes17[,bp.vars[c(10,12,14)]]
bpo.di = nhanes17[,bp.vars[c(11,13,15)]]
bpo.sy[is.na(bpo.sy)]=0
bpo.di[is.na(bpo.di)]=0
nhanes17$bpo.sy.m = apply(bpo.sy,1,sum)/apply(bpo.sy!=0,1,sum)
nhanes17$bpo.di.m = apply(bpo.di,1,sum)/apply(bpo.di!=0,1,sum)
bpo.sy.v = apply(bpo.sy,1,var_non0)
bpo.di.v = apply(bpo.di,1,var_non0)
par(mfrow=c(1,2))
#plot(nhanes17$bp.sy.m, nhanes17$bpo.sy.m, xlim=c(70, 250), ylim=c(70, 250),
#     xlab="Mercury device", ylab="Oscillometric device",
#     main="Systolic Blood Pressure")
#abline(0,1,col="red")
#abline(lm(nhanes17$bpo.sy.m~nhanes17$bp.sy.m), col="red", lty=2)
#plot(nhanes17$bp.di.m, nhanes17$bpo.di.m, xlim=c(30,140), ylim=c(30, 140),
#     xlab="Mercury device", ylab="Oscillometric device",
#     main="Diastolic Blood Pressure")
#abline(0,1,col="red")
#abline(lm(nhanes17$bpo.di.m~nhanes17$bp.di.m), col="red", lty=2)
nhanes17$bp.di.m[(is.na(nhanes17$bp.di.m))&(!is.na(nhanes17$bpo.di.m))]=nhanes17$bpo.di.m[(is.na(nhanes17$bp.di.m))&(!is.na(nhanes17$bpo.di.m))]
nhanes17$bp.sy.m[(is.na(nhanes17$bp.sy.m))&(!is.na(nhanes17$bpo.sy.m))]=nhanes17$bpo.sy.m[(is.na(nhanes17$bp.sy.m))&(!is.na(nhanes17$bpo.sy.m))]
# Combine nhanes 11-15, and nhanes 17
nhanes=nhanes[,-c(which(names(nhanes)%in%cmn.vars[!(cmn.vars%in%names(nhanes17))]),
                  which(names(nhanes)%in%c("alchl", "alc3", "bpo.di.m", "bpo.sy.m")))]

nhanes17=nhanes17[-c(which(names(nhanes17)%in%cmn.vars[!(cmn.vars%in%names(nhanes11))]),
                     which(names(nhanes17)%in%c("bpo.di.m", "bpo.sy.m")))]
nhanes=rbind(nhanes, nhanes17)
# heavy drinker
nhanes$hvy.drk = 1
nhanes$hvy.drk[(nhanes$drk_pdy>1)&(nhanes$RIAGENDR==2)]=2
nhanes$hvy.drk[(nhanes$drk_pdy>2)&(nhanes$RIAGENDR==1)]=2
nhanes$hvy.drk[nhanes$alc2==0]=0
table(nhanes$hvy.drk, nhanes$alc2)

# Physical activities
met_scr = function(yes_no, freq, hrs, scr){
  print(table(nhanes[,yes_no],useNA = "ifany"))
  nhanes[,yes_no][nhanes[,yes_no]>2]=NA
  nhanes[,hrs][nhanes[,hrs]==9999]=NA
  nhanes[,hrs][nhanes[,yes_no]==2]=0
  print(table(nhanes[,hrs],useNA = "ifany"))
  nhanes[,freq][nhanes[,freq]==99]=NA
  nhanes[,freq][nhanes[,yes_no]==2]=0
  print(table(nhanes[,freq],useNA = "ifany"))
  nhanes[,freq]*nhanes[,hrs]*scr
  
}
# Activity from bking/wlking
nhanes$bw_prwk = met_scr(yes_no="PAQ635", freq="PAQ640", hrs="PAD645", scr=4)
nhanes$bw_prwk[is.na(nhanes$bw_prwk)] = mean(nhanes$bw_prwk[!is.na(nhanes$bw_prwk)])
# Activity from leisure exercise; 
# Vigorous
nhanes$vig.l_prwk = met_scr(yes_no="PAQ650", freq="PAQ655", hrs="PAD660", scr=8)
nhanes$vig.l_prwk[is.na(nhanes$vig.l_prwk)] = mean(nhanes$vig.l_prwk[!is.na(nhanes$vig.l_prwk)])
# Moderate
nhanes$mod.l_prwk = met_scr(yes_no="PAQ665", freq="PAQ670", hrs="PAD675", scr=4)
nhanes$mod.l_prwk[is.na(nhanes$mod.l_prwk)] = mean(nhanes$mod.l_prwk[!is.na(nhanes$mod.l_prwk)])
# Activity from leisure work; 
# Vigorous
nhanes$vig.w_prwk = met_scr(yes_no="PAQ605", freq="PAQ610", hrs="PAD615", scr=8)
nhanes$vig.w_prwk[is.na(nhanes$vig.w_prwk)] = mean(nhanes$vig.w_prwk[!is.na(nhanes$vig.w_prwk)])
# Moderate
nhanes$mod.w_prwk = met_scr(yes_no="PAQ620", freq="PAQ625", hrs="PAD630", scr=4)
nhanes$mod.w_prwk[is.na(nhanes$mod.w_prwk)] = mean(nhanes$mod.w_prwk[!is.na(nhanes$mod.w_prwk)])
nhanes$phys.all = nhanes$bw_prwk+nhanes$vig.l_prwk+nhanes$vig.w_prwk+nhanes$mod.l_prwk+nhanes$mod.w_prwk
nhanes$phys.all=nhanes$phys.all/sum(nhanes$phys.all)*nrow(nhanes)
table(nhanes$phys.all,useNA = "ifany")
# Diabetes
table(as.numeric(nhanes$DIQ010==1), useNA = "ifany")
table(as.numeric(nhanes$DIQ010==1), (nhanes$LBXGH>=6.5), useNA = "ifany")
table(as.numeric(nhanes$DIQ010==1), (nhanes$LBXGLU>=126), useNA = "ifany")

nhanes$diabetes=0
nhanes$diabetes[(nhanes$DIQ010==1)|(nhanes$LBXGH>=6.5)|(nhanes$LBXGLU>=126)]=1
table(nhanes$diabetes)
# family history
nhanes$diab_fam = 0
nhanes$diab_fam[nhanes$DIQ175A==10]=1
table(nhanes$DIQ175A, nhanes$diab_fam, useNA = "ifany")
# prediabetes
nhanes$prediabetes = 0
nhanes$prediabetes[nhanes$DIQ160==1] = 1
table(nhanes$DIQ160, nhanes$prediabetes, useNA = "ifany")
table(nhanes$diabetes, nhanes$prediabetes, useNA = "ifany")
# gestation diab or baby>9lbs
nhanes$birth.risk = 0
nhanes$birth.risk[(nhanes$DIQ175S==28) | (nhanes$DIQ175F==15)] = 1
table(nhanes$birth.risk)
table(nhanes$birth.risk, nhanes$DIQ175S, useNA = "ifany")
table(nhanes$birth.risk, nhanes$DIQ175F, useNA = "ifany")

# Hypertension
table(nhanes$BPQ020, useNA = "ifany")
nhanes$hypertension =0
nhanes$hypertension[(nhanes$BPQ020==1)|(nhanes$bp.di.m>=80)|(nhanes$bp.sy.m>=130)]=1
table(nhanes$hypertension)
# Covairates
table(nhanes$cycle)
sum(is.na(nhanes$RIDAGEYR))
nhanes$sex=as.factor(2-nhanes$RIAGENDR)
levels(nhanes$sex)=c("Female", "Male")
table(nhanes$sex)
sum(is.na(nhanes$sex))
sum(is.na(nhanes$RIDRETH1))
nhanes$race4 = nhanes$RIDRETH1
nhanes$race4[nhanes$race4==1]=2
table(nhanes$race4)
nhanes$race4=as.factor(nhanes$race4)
levels(nhanes$race4)=c("Hispanic", "NH-White", "NH-Black", "NH-Other")
nhanes$race4 = factor(nhanes$race4, levels=c("NH-White", "NH-Black", "Hispanic", "NH-Other"))
# Education
table(nhanes$DMDEDUC2, useNA = "ifany")
nhanes$DMDEDUC2[nhanes$DMDEDUC2%in%c(7,9)]=4
table(nhanes$DMDEDUC3, useNA = "ifany")
nhanes$DMDEDUC3[nhanes$DMDEDUC3%in%c(7,9)]=13
nhanes$educ5 = nhanes$DMDEDUC2
nhanes$educ5[(is.na(nhanes$DMDEDUC2))&(nhanes$DMDEDUC3%in%c(0:8,55,66))]=1
nhanes$educ5[(is.na(nhanes$DMDEDUC2))&(nhanes$DMDEDUC3%in%c(9:12))]=2
nhanes$educ5[(is.na(nhanes$DMDEDUC2))&(nhanes$DMDEDUC3%in%c(13,14))]=3
nhanes$educ5[(is.na(nhanes$DMDEDUC2))&(nhanes$DMDEDUC3==15)]=4
table(nhanes$educ5, useNA = "ifany")
table(nhanes$DMDEDUC3, nhanes$educ5, useNA = "ifany")
table(nhanes$educ5,useNA = "ifany")
# Income     fam inc/yr, inc/pov,    fam inc/mth, pov indx,   pov cat
nhanes$INDFMIN2[nhanes$INDFMIN2>15]=NA
nhanes$IND235[nhanes$IND235>12]=NA
table(nhanes$INDFMIN2, nhanes$IND235, useNA = "ifany")
nhanes$INDFMIN2[(is.na(nhanes$INDFMIN2))&(!is.na(nhanes$IND235))]=nhanes$IND235[(is.na(nhanes$INDFMIN2))&(!is.na(nhanes$IND235))]
nhanes$INDFMIN2[nhanes$INDFMIN2==13]=round(mean(nhanes$INDFMIN2[nhanes$INDFMIN2%in%c(1:4)]))
nhanes$INDFMIN2[nhanes$INDFMIN2==12]=16
nhanes$INDFMIN2[nhanes$INDFMIN2==14]=11
nhanes$INDFMIN2[nhanes$INDFMIN2==15]=12
nhanes$INDFMIN2[nhanes$INDFMIN2==16]=round(mean(nhanes$INDFMIN2[nhanes$INDFMIN2%in%c(5:12)]))
nhanes$INDFMIN2[nhanes$INDFMIN2==13]=round(mean(nhanes$INDFMIN2[nhanes$INDFMIN2%in%c(1:4)]))
nhanes$INDFMIN2[is.na(nhanes$INDFMIN2)]=6
table(nhanes$INDFMIN2,useNA = "ifany")
nhanes$inc_3=cut(nhanes$INDFMIN2, breaks=c(1,5,10,12),include.lowest = T)
table(nhanes$inc_3,useNA = "ifany")
# Health insurance
nhanes$hlth_ins = nhanes$HIQ011
nhanes$hlth_ins[nhanes$HIQ011>2]=1
table(nhanes$SMQ020, useNA = "ifany")
nhanes$smk3 = 0
nhanes$smk3[(nhanes$SMQ020==1)&(nhanes$SMQ040%in%c(3,7))]=1
nhanes$smk3[(nhanes$SMQ020==1)&(nhanes$SMQ040%in%c(1,2))]=2
nhanes$smk3[(is.na(nhanes$SMQ020))|nhanes$SMQ020%in%c(7,9)]=0
nhanes$smk3[!is.na(nhanes$SMQ050Q)]=1
nhanes$smk3[(!is.na(nhanes$SMD641))|(!is.na(nhanes$SMD650))]=2
table(nhanes$smk3, useNA = "ifany")

table(nhanes$SMQ050Q, useNA = "ifany")
table(nhanes$SMQ050U, useNA = "ifany")
nhanes$smk5=nhanes$smk3
nhanes$smk5[nhanes$smk3==1]=2
nhanes$smk5[nhanes$smk3==2]=4
# cig/day
nhanes$cig_dy = nhanes$SMD641*nhanes$SMD650/30
nhanes$cig_dy[(nhanes$SMD641>70)|(nhanes$SMD650>100)]=NA
nhanes$smk5[nhanes$cig_dy<10]=3
nhanes$qt_yr = nhanes$SMQ050Q
nhanes$qt_yr[(nhanes$SMQ050U==1)&(!is.na(nhanes$SMQ050U))] = nhanes$SMQ050Q[(nhanes$SMQ050U==1)&(!is.na(nhanes$SMQ050U))]/365.25
nhanes$qt_yr[(nhanes$SMQ050U==2)&(!is.na(nhanes$SMQ050U))] = nhanes$SMQ050Q[(nhanes$SMQ050U==2)&(!is.na(nhanes$SMQ050U))]/(365.25/7)
nhanes$qt_yr[(nhanes$SMQ050U==3)&(!is.na(nhanes$SMQ050U))] = nhanes$SMQ050Q[(nhanes$SMQ050U==3)&(!is.na(nhanes$SMQ050U))]/12
nhanes$smk5[nhanes$qt_yr>=10]=1
table(nhanes$smk5,useNA = "ifany")
# BMI
sum(is.na(nhanes$BMXBMI)); sum(is.na(nhanes$BMXWT)); sum(is.na(nhanes$BMXHT))
nhanes$WHD020[nhanes$WHD020>1000]=NA; nhanes$WHD010[nhanes$WHD010>1000]=NA
nhanes$slfBMI = nhanes$WHD020*0.45359237/(nhanes$WHD010*0.0254)^2 
#plot(nhanes$BMXBMI, nhanes$slfBMI)
#abline(0,1,col="red")
#abline(lm(nhanes$slfBMI~nhanes$BMXBMI), col="red", lty=2)
nhanes$BMXBMI[(is.na(nhanes$BMXBMI))&(!is.na(nhanes$slfBMI))]=nhanes$slfBMI[(is.na(nhanes$BMXBMI))&(!is.na(nhanes$slfBMI))]
sum(is.na(nhanes$BMXBMI))
nhanes$bmi_c = cut(nhanes$BMXBMI, breaks=c(0, 18.5, 25, 30, 100), right=F)
nhanes$bmi_c = as.factor(nhanes$bmi_c)
nhanes$bmi_c = factor(nhanes$bmi_c, levels = c("[18.5,25)", "[0,18.5)", "[25,30)", "[30,100)"))
table(nhanes$bmi_c, useNA = "ifany")
nhanes$bmi_c3 = cut(nhanes$BMXBMI, breaks=c(0, 25, 30, 100), right=F)
nhanes$bmi_c3 = as.factor(nhanes$bmi_c3)
nhanes$bmi_c3 = factor(nhanes$bmi_c3, levels = c("[0,25)", "[25,30)", "[30,100)"))
table(nhanes$bmi_c3, useNA = "ifany")

# WH ratio
nhanes$WHR = nhanes$BMXWAIST/nhanes$BMXHT
nhanes$WHR[(is.na(nhanes$BMXHT))&(!is.na(nhanes$WHD010))]=(nhanes$BMXWAIST/nhanes$WHD010*0.0254)[(is.na(nhanes$BMXHT))&(!is.na(nhanes$WHD010))]
sum(is.na(nhanes$WHR))
nhanes$TTR = nhanes$DXXTRFAT/nhanes$DXDTOFAT
nhanes$NAFLD = NA
nhanes$NAFLD[nhanes$LUXCAPM>263]=1
nhanes$NAFLD[nhanes$LUXCAPM<=263]=0
table(nhanes$NAFLD, useNA = "ifany")
nhanes$NAFLD.cmp = nhanes$NAFLD
nhanes$NAFLD.cmp[nhanes$cycle%in%c(1:3)]=99
table(nhanes$NAFLD.cmp, nhanes$NAFLD, useNA = "ifany")
# age
nhanes$age_c6=cut(nhanes$RIDAGEYR, breaks=c(18,seq(30,80,10)),include.lowest=T)

nhanes.cmp = nhanes[nhanes$hvy.drk<2,c("SDMVPSU", "SDMVSTRA", "WTINT2YR", "cycle", 
                       "diabetes", "diab_fam", "prediabetes", "birth.risk", 
                       "RIDAGEYR", "sex", "age_c6", "race4", "smk3", "smk5", "hvy.drk", "hypertension", "phys.all", 
                       "BMXBMI", "bmi_c", "bmi_c3", "BMXWAIST", "LBXSTR", "LBXSGTSI", "LBXSATSI", "NAFLD", "NAFLD.cmp", "LUXCAPM"#,
                       #"DXXVFATA", "DXXTATA"
                       )]

comp.idx = complete.cases(nhanes.cmp[,!(names(nhanes.cmp)%in%c("NAFLD", "LUXCAPM"))])
#comp.idx = complete.cases(nhanes.cmp[,!(names(nhanes.cmp)%in%c("DXXVFATA", "DXXTATA", "NAFLD", "LUXCAPM"))])&DXXVFATA.idx&DXXTATA.idx
nhanes.cmp=nhanes.cmp[comp.idx,]
nhanes17.cmp=nhanes.cmp[nhanes.cmp$cycle==4,]
ds.nhanes=svydesign(id=~SDMVPSU, strata=~SDMVSTRA, weight=~WTINT2YR, nest=T, data=nhanes.cmp)
ds.nhanes17 = subset(ds.nhanes, cycle==4) 
cov.dist = function(vars, label=NULL){
  ds.all   = svydesign(id=~SDMVPSU, strata=~SDMVSTRA, weight=~WTINT2YR, nest=T, data=nhanes)
  ds.all17 = svydesign(id=~SDMVPSU, strata=~SDMVSTRA, weight=~WTINT2YR, nest=T, data=nhanes[nhanes$cycle==4,])
  tab = cbind(table(nhanes[,vars]),
              svytable(as.formula(paste0("~", vars)), design=ds.all)/sum(nhanes$WTINT2YR),
              table(nhanes[nhanes$cycle==4,vars]),
              svytable(as.formula(paste0("~", vars)), design=ds.all17)/sum(nhanes$WTINT2YR[nhanes$cycle==4]),
              table(nhanes.cmp[,vars]),
              svytable(as.formula(paste0("~", vars)), design=ds.nhanes)/sum(nhanes.cmp$WTINT2YR),
              table(nhanes.cmp[nhanes.cmp$cycle==4,vars]),
              svytable(as.formula(paste0("~", vars)), design=ds.nhanes17)/sum(nhanes.cmp$WTINT2YR[nhanes.cmp$cycle==4]))
  if(!is.null(label)){
    row.names(tab) = label
  }
  tab
}
covar.dists = rbind(cov.dist("age_c6"),
                    cov.dist("sex", c("Male", "Female")),
                    cov.dist("race4"),
                    #cov.dist("educ5", c("<9th grd", "9-11 grd", "Hgh Schl", "Sm Clg/AA", ">=Clg grd")),
                    #cov.dist("inc_3", c("<25k", "25k-75k", ">=75k")),
                    #cov.dist("hlth_ins", c("Have Ins", "No Ins")),
                    cov.dist("smk5",    c("Never", "Qt>=10yrs", "Qt<10yrs", "<10cig/dy", ">=10cig/dy")),
                    cov.dist("hvy.drk", c("Non-crnt", "Non-hvy", "hvy")),
                    cov.dist("bmi_c"),
                    cov.dist("hypertension", c("No-hytn"    , "Yes-hytm"    )),
                    cov.dist("diab_fam"    , c("No-fam.h"   , "Yes-fam.h"   )),
                    cov.dist("prediabetes" , c("No-pre.diab", "Yes-pre.diab")),
                    cov.dist("birth.risk"  , c("No-b.risk"  , "Yes-b.risk"  )),
                    cov.dist("NAFLD"       , c("No-nafld"   , "Yes-nafld"   )),
                    cov.dist("diabetes"    , c("No-diab"    , "Yes-diab"    ))
)
covar.dists
# Check missing for important variables
c(sum(is.na(nhanes$diabetes)), sum(is.na(nhanes$diabetes[nhanes$cycle==4])))
c(sum(is.na(nhanes$BMXWAIST)), sum(is.na(nhanes$BMXWAIST[nhanes$cycle==4])))
c(sum(is.na(nhanes$bmi_c)), sum(is.na(nhanes$bmi_c[nhanes$cycle==4])))
c(sum(is.na(nhanes$hypertension)), sum(is.na(nhanes$hypertension[nhanes$cycle==4])))
sum(is.na(nhanes$LUXCAPM[nhanes$cycle==4]))
c(sum(is.na(nhanes$LBXSGTSI)), sum(is.na(nhanes$LBXSGTSI[nhanes$cycle==4])))
c(sum(is.na(nhanes$LBXSTR)), sum(is.na(nhanes$LBXSTR[nhanes$cycle==4])))
c(sum(is.na(nhanes$LBXSATSI)), sum(is.na(nhanes$LBXSATSI[nhanes$cycle==4])))


############################### impute NAFLD ############################### 
########### FLI index from external sources
odds.NAFLD=exp(-15.745+0.953*log(nhanes.cmp$LBXSTR)+0.139*nhanes.cmp$BMXBMI+0.718*log(nhanes.cmp$LBXSGTSI)+0.053*nhanes.cmp$BMXWAIST)
nhanes.cmp$FLI = odds.NAFLD/(1+odds.NAFLD)
nhanes.cmp$FLI60 = as.numeric(nhanes.cmp$FLI>0.6)
sum(!is.na(nhanes.cmp$FLI[nhanes.cmp$cycle==4]))
table(nhanes.cmp$NAFLD, nhanes.cmp$FLI60)
#    0    1
#0 1721  573
#1  628 1719
cor(nhanes.cmp$FLI[(!is.na(nhanes.cmp$FLI))&(!is.na(nhanes.cmp$LUXCAPM))], nhanes.cmp$LUXCAPM[(!is.na(nhanes.cmp$FLI))&(!is.na(nhanes.cmp$LUXCAPM))])
#[1] 0.6276633
# Use FLI to impute NAFLD and CAP
nhanes.cmp$NAFLD.i = nhanes.cmp$FLI60
nhanes.cmp$NAFLD.i[!is.na(nhanes.cmp$NAFLD)] = nhanes.cmp$NAFLD[!is.na(nhanes.cmp$NAFLD)]
ds.nhanes17 = update(ds.nhanes17, FLI=nhanes.cmp$FLI[nhanes.cmp$cycle==4])
nhanes.cmp$CAP.i = cbind(1, nhanes.cmp$FLI)%*%c(svyglm(LUXCAPM~FLI, family="gaussian", ds.nhanes17)$coeff)
nhanes.cmp$CAP.i[!is.na(nhanes.cmp$LUXCAPM)] = nhanes.cmp$LUXCAPM[!is.na(nhanes.cmp$LUXCAPM)]
########### FLI index from nhanes
NAFLD.FLI = svyglm(NAFLD~I(log(LBXSTR))+BMXBMI+I(log(LBXSGTSI))+BMXWAIST,#+I(log(LBXSATSI)), 
                   family = "binomial", design = ds.nhanes17)
summary(NAFLD.FLI)
odds.NAFLD.i = exp(cbind(1, log(nhanes.cmp$LBXSTR), nhanes.cmp$BMXBMI, log(nhanes.cmp$LBXSGTSI), nhanes.cmp$BMXWAIST#, 
                         #log(nhanes.cmp$LBXSATSI)
                         )%*%c(NAFLD.FLI$coeff))
nhanes.cmp$FLI.i = odds.NAFLD.i/(1+odds.NAFLD.i)
nhanes.cmp$FLI.i60 = as.numeric(nhanes.cmp$FLI.i>0.6)
table(nhanes.cmp$NAFLD, nhanes.cmp$FLI.i60)
#    0    1
#0 1940  354
#1  879 1468
cor(nhanes.cmp$FLI.i[(!is.na(nhanes.cmp$FLI.i))&(!is.na(nhanes.cmp$LUXCAPM))], nhanes.cmp$LUXCAPM[(!is.na(nhanes.cmp$FLI.i))&(!is.na(nhanes.cmp$LUXCAPM))])
#[1] 0.642523

nhanes.cmp$NAFLD.ii = nhanes.cmp$FLI.i60
nhanes.cmp$NAFLD.ii[!is.na(nhanes.cmp$NAFLD)] = nhanes.cmp$NAFLD[!is.na(nhanes.cmp$NAFLD)]
ds.nhanes17 = update(ds.nhanes17, FLI.i=nhanes.cmp$FLI.i[nhanes.cmp$cycle==4])
nhanes.cmp$CAP.ii = cbind(1, nhanes.cmp$FLI.i)%*%c(svyglm(LUXCAPM~FLI.i, family="gaussian", ds.nhanes17)$coeff)
nhanes.cmp$CAP.ii[!is.na(nhanes.cmp$LUXCAPM)] = nhanes.cmp$LUXCAPM[!is.na(nhanes.cmp$LUXCAPM)]

ds.nhanes=svydesign(id=~SDMVPSU, strata=~SDMVSTRA, weight=~WTINT2YR, nest=T, data=nhanes.cmp)
ds.nhanes17 = subset(ds.nhanes, cycle==4) 

####################################### Diabetes model #######################################################
diab.fit = "diabetes~RIDAGEYR+as.factor(sex)+as.factor(race4)+as.factor(bmi_c3)+hypertension+phys.all"
interact="*as.factor(sex)"
#interact = "*RIDAGEYR"
######### Diabetes~NAFLD ######### 
# nhanes 17 model
diab.NAFLD = svyglm(as.formula(paste0(diab.fit, paste0("+NAFLD", interact))), family="binomial", design=ds.nhanes17)
summary(diab.NAFLD)
# nhanes 11-17 model, with imputed NAFLD
# Imputation models
diab.NAFLD.i  = svyglm(as.formula(paste0(diab.fit, paste0("+NAFLD.i", interact))),  family="binomial", design=ds.nhanes)
summary(diab.NAFLD.i)
diab.NAFLD.ii = svyglm(as.formula(paste0(diab.fit, paste0("+NAFLD.ii", interact))), family="binomial", design=ds.nhanes)
summary(diab.NAFLD.ii)
# calibration models
diab.FLI     = svyglm(as.formula(paste0(diab.fit, paste0("+FLI"    , interact))), family="binomial", design=ds.nhanes)
diab.FLI17   = svyglm(as.formula(paste0(diab.fit, paste0("+FLI"    , interact))), family="binomial", design=ds.nhanes17)
diab.FLI.i   = svyglm(as.formula(paste0(diab.fit, paste0("+FLI.i"  , interact))), family="binomial", design=ds.nhanes)
diab.FLI60   = svyglm(as.formula(paste0(diab.fit, paste0("+FLI60"  , interact))), family="binomial", design=ds.nhanes)
diab.FLI.i60 = svyglm(as.formula(paste0(diab.fit, paste0("+FLI.i60", interact))), family="binomial", design=ds.nhanes)
######### Diabetes~CAP ######### 
# nhanes 17 model
diab.CAP = svyglm(as.formula(paste0(diab.fit, paste0("+LUXCAPM", interact))), family="binomial", design=ds.nhanes17)
summary(diab.CAP)
# nhanes 11-17 model, with imputed NAFLD
# Imputation models
diab.CAP.i  = svyglm(as.formula(paste0(diab.fit, paste0("+CAP.i", interact))),  family="binomial", design=ds.nhanes)
summary(diab.CAP.i)
diab.CAP.ii = svyglm(as.formula(paste0(diab.fit, paste0("+CAP.ii", interact))), family="binomial", design=ds.nhanes)
summary(diab.CAP.ii)

calib_f = function(imp.mdl, calib.var=NULL){
  p.tilde = imp.mdl$fitted.values
  x.mtx = model.matrix(imp.mdl)
  beta.tilde_di = t(solve(t(nhanes.cmp$WTINT2YR*p.tilde*(1-p.tilde)*x.mtx)%*%x.mtx)%*%
                      t((nhanes.cmp$diabetes-p.tilde)*x.mtx))
  n.clib = colnames(x.mtx)%in%c(calib.var)
  if(!is.null(calib.var)) beta.tilde_di=matrix(beta.tilde_di[,n.clib],,sum(n.clib)) 
  N.hat=sum(nhanes.cmp$WTINT2YR)/4
  diab_N = nhanes.cmp$diabetes/N.hat
  if(ncol(beta.tilde_di)==1){
    aux.mtx = data.frame(cnt = 1/N.hat, 
                         diab_N=diab_N[nhanes.cmp$cycle==4], 
                         Delta_beta = beta.tilde_di[nhanes.cmp$cycle==4])
    aux.tot = c(1, sum(diab_N*nhanes.cmp$WTINT2YR)/4,
                0)
  }else{
    aux.mtx = data.frame(cnt = 1/N.hat, 
                         diab_N=diab_N[nhanes.cmp$cycle==4], 
                         Delta_beta = beta.tilde_di[nhanes.cmp$cycle==4,])
    aux.tot = c(1, sum(diab_N*nhanes.cmp$WTINT2YR)/4, 
                colSums(beta.tilde_di*nhanes.cmp$WTINT2YR)/4)
  }
  names(aux.tot) = c("(Intercept)", names(aux.mtx)[-1])
  greg_beta = greg.f(samp=nhanes17.cmp, wt0="WTINT2YR", N.hat=N.hat, aux.mtx=aux.mtx, aux.tot=aux.tot, f_w=F)
  range(greg_beta$f); sum(greg_beta$f<0)
  greg_beta$f[greg_beta$f<=0]=1e-10
  greg_beta$f
}
nhanes17.cmp = nhanes.cmp[nhanes.cmp$cycle==4,]
nhanes17.cmp$calib.fli     = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=diab.FLI)
nhanes17.cmp$calib.fli.i   = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=diab.FLI.i)
nhanes17.cmp$calib.fli60   = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=diab.FLI60)
nhanes17.cmp$calib.fli60.i = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=diab.FLI.i60)
beta.est.fun = function(x=NULL, wt, fm = NULL){
  ds = svydesign(id=~SDMVPSU, strata=~SDMVSTRA, weight=as.formula(paste0("~", wt)), 
                 nest=T, data=nhanes17.cmp)
  if((is.null(fm))&(!is.null(x))) fm = as.formula(paste0(diab.fit, "+",x))
  fit  = svyglm(fm, family="binomial", design=ds)
  fit$coeff
}

U.tilde_beta.tilde=-t(c(diab.FLI60$fitted.values*(1-diab.FLI60$fitted.values))*model.matrix(diab.FLI60))%*%model.matrix(diab.FLI60)
v.mtx.FLI60 = t(solve(U.tilde_beta.tilde)%*%
                  t(c(nhanes.cmp$diabetes-diab.FLI60$fitted.values)*model.matrix(diab.FLI60)))
calib.fli60.out0  = beta.est.var0(ds      = ds.nhanes, 
                                  fit     = as.formula(paste0(diab.fit, paste0("+NAFLD", interact))), 
                                  v.mtx   = v.mtx.FLI60, 
                                  cyc     = "cycle", 
                                  sub.cyl = 4, 
                                  method="linear")

NFLD_est = cbind(diab.NAFLD$coefficients, 
                 diab.NAFLD.i$coefficients,            diab.NAFLD.ii$coefficients, 
                 beta.est.fun(paste0("NAFLD", interact), "calib.fli60"), beta.est.fun(paste0("NAFLD", interact), "calib.fli60.i"),
                 beta.est.fun(paste0("NAFLD", interact), "calib.fli"),   beta.est.fun(paste0("NAFLD", interact), "calib.fli.i")
                 )
NFLD_var.TL = matrix(calib.fli60.out0$var.all[1:length(diab.NAFLD$coefficients)],,1)

write_xlsx(as.data.frame(cbind(rownames(NFLD_est), NFLD_est)), col_names = F,
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/NFLD_est_sex.xlsx")
write_xlsx(as.data.frame(cbind(rownames(NFLD_var.TL), NFLD_var.TL)), col_names = F,
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/NFLD_var.TL_sex.xlsx")

U.tilde_beta.tilde=-t(c(diab.FLI$fitted.values*(1-diab.FLI$fitted.values))*model.matrix(diab.FLI))%*%model.matrix(diab.FLI)
v.mtx.FLI = t(solve(U.tilde_beta.tilde)%*%
                  t(c(nhanes.cmp$diabetes-diab.FLI$fitted.values)*model.matrix(diab.FLI)))
calib.fli.out0  = beta.est.var0(ds      = ds.nhanes, 
                                fit     = as.formula(paste0(diab.fit, paste0("+LUXCAPM", interact))), 
                                v.mtx   = v.mtx.FLI, 
                                cyc     = "cycle", 
                                sub.cyl = 4, 
                                method="linear")
CAP_var.TL = matrix(calib.fli.out0$var.all[1:length(diab.CAP$coefficients)],,1)

CAP_est = cbind(diab.CAP$coefficients,              #diab.FLI$coefficients, 
                diab.CAP.i$coefficients,            diab.CAP.ii$coefficients, 
                beta.est.fun(paste0("LUXCAPM", interact), "calib.fli"),   
                beta.est.fun(paste0("LUXCAPM", interact), "calib.fli.i")
                 )
CAP_est

write_xlsx(as.data.frame(cbind(rownames(CAP_est), CAP_est)), col_names = F, 
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/CAP_est_sex.xlsx")
write_xlsx(as.data.frame(cbind(rownames(CAP_var.TL), CAP_var.TL)), col_names = F,
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/CAP_var.TL_sex.xlsx")

####################################### NAFLD model #######################################################
NAFLD.fit = "NAFLD~RIDAGEYR+as.factor(sex)+as.factor(race4)+as.factor(bmi_c3)+hypertension+phys.all+diabetes"
#interact=""
#interact="*as.factor(sex)"
#interact = "*RIDAGEYR"
######### NAFLD~Diabetes ######### 
# nhanes 17 model
NAFLD.diab = svyglm(as.formula(NAFLD.fit), family="binomial", design=ds.nhanes17)
summary(NAFLD.diab)
# nhanes 11-17 model, with imputed NAFLD
# Imputation models
NAFLD.i.diab  = svyglm(as.formula(gsub("NAFLD", "NAFLD.i", NAFLD.fit)),  family="binomial", design=ds.nhanes)
summary(NAFLD.i.diab)
NAFLD.ii.diab = svyglm(as.formula(gsub("NAFLD", "NAFLD.ii", NAFLD.fit)), family="binomial", design=ds.nhanes)
summary(NAFLD.ii.diab)
# calibration models
FLI60.diab     = svyglm(as.formula(gsub("NAFLD", "FLI60"  , NAFLD.fit)), family="binomial", design=ds.nhanes)
FLI.i60.diab   = svyglm(as.formula(gsub("NAFLD", "FLI.i60", NAFLD.fit)), family="binomial", design=ds.nhanes)

nhanes17.cmp = nhanes.cmp[nhanes.cmp$cycle==4,]
nhanes17.cmp$calib.fli60.y   = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=FLI60.diab)
nhanes17.cmp$calib.fli60.i.y = nhanes17.cmp$WTINT2YR*calib_f(imp.mdl=FLI.i60.diab)

U.tilde_beta.tilde.y=-t(c(FLI60.diab$fitted.values*(1-FLI60.diab$fitted.values))*model.matrix(FLI60.diab))%*%model.matrix(FLI60.diab)
v.mtx.FLI60.y = t(solve(U.tilde_beta.tilde)%*%
                t(c(nhanes.cmp$FLI60-FLI60.diab$fitted.values)*model.matrix(FLI60.diab)))
calib.fli60.y.out0  = beta.est.var0(ds      = ds.nhanes, 
                                    fit     = as.formula(NAFLD.fit), 
                                    v.mtx   = v.mtx.FLI60.y, 
                                    cyc     = "cycle", 
                                    sub.cyl = 4, 
                                    method="linear")

NFLD.y_est = cbind(NAFLD.diab$coefficients, 
                   NAFLD.i.diab$coefficients, NAFLD.ii.diab$coefficients, 
                   beta.est.fun(wt="calib.fli60.y", fm=NAFLD.fit), beta.est.fun(wt="calib.fli60.i.y", fm=NAFLD.fit))

NFLD.y_var.TL = matrix(calib.fli60.out0$var.all[1:length(NAFLD.diab$coefficients)],,1)

write_xlsx(as.data.frame(cbind(rownames(NFLD_est), NFLD_est)), col_names = F,
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/NFLD.y_est.xlsx")
write_xlsx(as.data.frame(cbind(rownames(NFLD_var.TL), NFLD_var.TL)), col_names = F,
           "/Users/wangl29/Dropbox/Research/Projects&Literature Lingxiao/Calibration multiple surveys/NFLD.y_var.TL.xlsx")

